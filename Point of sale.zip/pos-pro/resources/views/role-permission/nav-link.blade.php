<div class="container mt-3">
    <a href="{{url('/dashboard')}}" class="btn btn-primary mx-2">Dashboard</a>
    <a href="{{url('/roles')}}" class="btn btn-primary mx-2">Roles</a>
    <a href="{{url('/permissions')}}" class="btn btn-info mx-2">Permission</a>
    <a href="{{url('/users')}}" class="btn btn-warning mx-2">Users</a>
</div>